
SET client_encoding = 'UTF8';


ALTER RESOURCE QUEUE pg_default WITH (ACTIVE_STATEMENTS=20);

ALTER RESOURCE GROUP admin_group SET CPU_RATE_LIMIT 1;

ALTER RESOURCE GROUP admin_group SET MEMORY_LIMIT 1;

ALTER RESOURCE GROUP default_group SET CPU_RATE_LIMIT 1;

ALTER RESOURCE GROUP default_group SET MEMORY_LIMIT 1;

ALTER RESOURCE GROUP default_group SET MEMORY_LIMIT 0;

ALTER RESOURCE GROUP default_group SET MEMORY_SHARED_QUOTA 80;

ALTER RESOURCE GROUP default_group SET MEMORY_SPILL_RATIO 0;

ALTER RESOURCE GROUP default_group SET CONCURRENCY 20;

ALTER RESOURCE GROUP default_group SET CPU_RATE_LIMIT 30;

ALTER RESOURCE GROUP admin_group SET MEMORY_LIMIT 10;

ALTER RESOURCE GROUP admin_group SET MEMORY_SHARED_QUOTA 80;

ALTER RESOURCE GROUP admin_group SET MEMORY_SPILL_RATIO 0;

ALTER RESOURCE GROUP admin_group SET CONCURRENCY 10;

ALTER RESOURCE GROUP admin_group SET CPU_RATE_LIMIT 10;

CREATE ROLE gpadmin;
ALTER ROLE gpadmin WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION PASSWORD 'md5b44a9b06d576a0b083cd60e5f875cf48' RESOURCE QUEUE pg_default RESOURCE GROUP admin_group CREATEEXTTABLE (protocol='http') CREATEEXTTABLE (protocol='gpfdist', type='readable') CREATEEXTTABLE (protocol='gpfdist', type='writable');

CREATE ROLE testrole;
ALTER ROLE testrole WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN RESOURCE QUEUE pg_default RESOURCE GROUP default_group;



CREATE DATABASE test TEMPLATE template0;

ALTER DATABASE test OWNER TO testrole;



COMMENT ON SCHEMA public IS 'standard public schema';


ALTER SCHEMA public OWNER TO gpadmin;


REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM gpadmin;
GRANT ALL ON SCHEMA public TO PUBLIC;
GRANT ALL ON SCHEMA public TO gpadmin;




CREATE TABLE public.a (
	"int" integer,
	text text
) DISTRIBUTED BY ("int");


ALTER TABLE public.a OWNER TO gpadmin;


CREATE TABLE public.b (
	"int" integer,
	text text
) DISTRIBUTED BY ("int");


ALTER TABLE public.b OWNER TO gpadmin;


CREATE TABLE public.c (
	"int" integer,
	text text
) DISTRIBUTED BY ("int");


ALTER TABLE public.c OWNER TO gpadmin;


CREATE TABLE public.d (
	"int" integer,
	text text
) DISTRIBUTED BY ("int");


ALTER TABLE public.d OWNER TO gpadmin;


CREATE TABLE public.e (
	"int" integer,
	text text
) DISTRIBUTED BY ("int");


ALTER TABLE public.e OWNER TO gpadmin;


CREATE TABLE public.f (
	"int" integer,
	text text
) DISTRIBUTED BY ("int");


ALTER TABLE public.f OWNER TO gpadmin;


CREATE TABLE public.g (
	"int" integer,
	text text
) DISTRIBUTED BY ("int");


ALTER TABLE public.g OWNER TO gpadmin;


CREATE TABLE public.h (
	"int" integer,
	text text
) DISTRIBUTED BY ("int");


ALTER TABLE public.h OWNER TO gpadmin;


CREATE TABLE public.i (
	"int" integer,
	text text
) DISTRIBUTED BY ("int");


ALTER TABLE public.i OWNER TO gpadmin;


CREATE TABLE public.j (
	"int" integer,
	text text
) DISTRIBUTED BY ("int");


ALTER TABLE public.j OWNER TO gpadmin;
